def coincidence():
    print 'test'
