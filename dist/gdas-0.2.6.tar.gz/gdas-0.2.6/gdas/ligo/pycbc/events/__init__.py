"""
This packages contains modules for clustering events
"""

from events import *
from veto import *
from coinc import *

