# Import SWIG wrappings, if available
from .lalburst import *
